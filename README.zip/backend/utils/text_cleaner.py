def normalize_text(text):
    return " ".join(text.split())
