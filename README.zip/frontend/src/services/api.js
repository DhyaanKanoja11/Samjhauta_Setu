import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:8000", // change when deployed
});

export const analyzeContract = async (formData) => {
  const response = await API.post("/analyze", formData, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });

  return response.data;
};
