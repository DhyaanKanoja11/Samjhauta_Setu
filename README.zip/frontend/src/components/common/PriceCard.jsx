import PropTypes from 'prop-types';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

export default function PriceCard({
    crop,
    price,
    unit = '₹/quintal',
    change,
    changePercent,
    image,
    onClick
}) {
    const getTrendIcon = () => {
        if (change > 0) return <TrendingUp className="w-5 h-5" />;
        if (change < 0) return <TrendingDown className="w-5 h-5" />;
        return <Minus className="w-5 h-5" />;
    };

    const getTrendClass = () => {
        if (change > 0) return 'price-up';
        if (change < 0) return 'price-down';
        return 'price-neutral';
    };

    return (
        <div
            className="card-hover cursor-pointer"
            onClick={onClick}
        >
            <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                    {image && (
                        <div className="w-12 h-12 rounded-lg bg-primary-50 flex items-center justify-center overflow-hidden">
                            <img src={image} alt={crop} className="w-full h-full object-cover" />
                        </div>
                    )}
                    <div>
                        <h3 className="font-semibold text-lg text-neutral-800">{crop}</h3>
                        <p className="text-sm text-neutral-500">{unit}</p>
                    </div>
                </div>
                <div className={`flex items-center gap-1 ${getTrendClass()}`}>
                    {getTrendIcon()}
                </div>
            </div>

            <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-neutral-900">₹{price}</span>
                    <span className="text-sm text-neutral-500">/{unit.split('/')[1]}</span>
                </div>

                {changePercent !== undefined && (
                    <div className={`flex items-center gap-2 text-sm font-medium ${getTrendClass()}`}>
                        <span>{change > 0 ? '+' : ''}{change}</span>
                        <span>({changePercent > 0 ? '+' : ''}{changePercent}%)</span>
                    </div>
                )}
            </div>
        </div>
    );
}

PriceCard.propTypes = {
    crop: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    unit: PropTypes.string,
    change: PropTypes.number,
    changePercent: PropTypes.number,
    image: PropTypes.string,
    onClick: PropTypes.func,
};
