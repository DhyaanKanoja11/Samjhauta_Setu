import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Search, TrendingUp, MapPin, Calendar } from 'lucide-react';
import PriceCard from '../common/PriceCard';
import Card from '../common/Card';

// Mock data - will be replaced with API calls
const mockMandiPrices = [
    { id: 1, crop: 'गेहूं (Wheat)', price: 2150, change: 50, changePercent: 2.4, unit: '₹/quintal', image: null },
    { id: 2, crop: 'धान (Rice)', price: 1950, change: -30, changePercent: -1.5, unit: '₹/quintal', image: null },
    { id: 3, crop: 'मक्का (Maize)', price: 1800, change: 75, changePercent: 4.3, unit: '₹/quintal', image: null },
    { id: 4, crop: 'सोयाबीन (Soybean)', price: 4200, change: 100, changePercent: 2.4, unit: '₹/quintal', image: null },
    { id: 5, crop: 'चना (Chickpea)', price: 5100, change: 0, changePercent: 0, unit: '₹/quintal', image: null },
    { id: 6, crop: 'सरसों (Mustard)', price: 5500, change: 150, changePercent: 2.8, unit: '₹/quintal', image: null },
];

export default function MandiPrices({ compact = false }) {
    const [prices, setPrices] = useState(mockMandiPrices);
    const [loading, setLoading] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedLocation, setSelectedLocation] = useState('सभी मंडियां');

    useEffect(() => {
        // Simulate API call
        setLoading(true);
        setTimeout(() => {
            setPrices(mockMandiPrices);
            setLoading(false);
        }, 500);
    }, []);

    const filteredPrices = prices.filter(item =>
        item.crop.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const displayPrices = compact ? filteredPrices.slice(0, 4) : filteredPrices;

    if (loading) {
        return (
            <div className="space-y-4">
                {[1, 2, 3, 4].map(i => (
                    <div key={i} className="shimmer h-32 rounded-xl" />
                ))}
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between flex-wrap gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-neutral-900">मंडी भाव</h2>
                    <p className="text-neutral-600 mt-1">आज के ताज़ा बाज़ार दर</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-neutral-600">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date().toLocaleDateString('hi-IN', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric'
                    })}</span>
                </div>
            </div>

            {/* Filters */}
            {!compact && (
                <Card className="!p-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Search */}
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                            <input
                                type="text"
                                placeholder="फसल खोजें..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="input pl-10"
                            />
                        </div>

                        {/* Location */}
                        <div className="relative">
                            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                            <select
                                value={selectedLocation}
                                onChange={(e) => setSelectedLocation(e.target.value)}
                                className="input pl-10 appearance-none"
                            >
                                <option>सभी मंडियां</option>
                                <option>दिल्ली</option>
                                <option>पंजाब</option>
                                <option>हरियाणा</option>
                                <option>उत्तर प्रदेश</option>
                                <option>मध्य प्रदेश</option>
                            </select>
                        </div>
                    </div>
                </Card>
            )}

            {/* Price Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {displayPrices.map(item => (
                    <PriceCard
                        key={item.id}
                        crop={item.crop}
                        price={item.price}
                        change={item.change}
                        changePercent={item.changePercent}
                        unit={item.unit}
                        image={item.image}
                        onClick={() => console.log('View details for', item.crop)}
                    />
                ))}
            </div>

            {/* Summary Stats */}
            {!compact && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card className="text-center">
                        <div className="flex items-center justify-center gap-2 text-success mb-2">
                            <TrendingUp className="w-6 h-6" />
                            <span className="text-3xl font-bold">
                                {prices.filter(p => p.change > 0).length}
                            </span>
                        </div>
                        <p className="text-neutral-600">बढ़ती कीमतें</p>
                    </Card>

                    <Card className="text-center">
                        <div className="flex items-center justify-center gap-2 text-error mb-2">
                            <TrendingUp className="w-6 h-6 rotate-180" />
                            <span className="text-3xl font-bold">
                                {prices.filter(p => p.change < 0).length}
                            </span>
                        </div>
                        <p className="text-neutral-600">गिरती कीमतें</p>
                    </Card>

                    <Card className="text-center">
                        <div className="flex items-center justify-center gap-2 text-neutral-500 mb-2">
                            <span className="text-3xl font-bold">
                                {prices.filter(p => p.change === 0).length}
                            </span>
                        </div>
                        <p className="text-neutral-600">स्थिर कीमतें</p>
                    </Card>
                </div>
            )}

            {compact && filteredPrices.length > 4 && (
                <button className="btn-outline w-full">
                    सभी मंडी भाव देखें ({filteredPrices.length})
                </button>
            )}
        </div>
    );
}

MandiPrices.propTypes = {
    compact: PropTypes.bool,
};
