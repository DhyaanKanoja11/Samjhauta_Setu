import { useState, useRef } from 'react';
import { Camera, Upload, X, FileText, Check, Loader } from 'lucide-react';
import Card from '../common/Card';
import Button from '../common/Button';

export default function DocumentScanner() {
    const [selectedFile, setSelectedFile] = useState(null);
    const [preview, setPreview] = useState(null);
    const [isProcessing, setIsProcessing] = useState(false);
    const [extractedText, setExtractedText] = useState('');
    const [isComplete, setIsComplete] = useState(false);
    const fileInputRef = useRef(null);

    const handleFileSelect = (e) => {
        const file = e.target.files[0];
        if (file && file.type.startsWith('image/')) {
            setSelectedFile(file);
            setIsComplete(false);
            setExtractedText('');

            // Create preview
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreview(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleScan = async () => {
        if (!selectedFile) return;

        setIsProcessing(true);

        // Simulate OCR processing (will be replaced with actual API call)
        setTimeout(() => {
            const mockText = `दस्तावेज़ प्रकार: भूमि रिकॉर्ड
      
खाता संख्या: 12345/2024
किसान का नाम: राजेश कुमार
पिता का नाम: रामप्रसाद शर्मा
गांव: रामपुर
तहसील: सदर
जिला: मेरठ

भूमि विवरण:
खसरा संख्या: 456
क्षेत्रफल: 2.5 एकड़
फसल: गेहूं

दिनांक: ${new Date().toLocaleDateString('hi-IN')}`;

            setExtractedText(mockText);
            setIsProcessing(false);
            setIsComplete(true);
        }, 2000);
    };

    const handleReset = () => {
        setSelectedFile(null);
        setPreview(null);
        setExtractedText('');
        setIsComplete(false);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-bold text-neutral-900">दस्तावेज़ स्कैनर</h2>
                <p className="text-neutral-600 mt-1">अपने दस्तावेज़ों को स्कैन करें और टेक्स्ट निकालें</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Upload Section */}
                <Card>
                    <h3 className="font-semibold text-lg mb-4">दस्तावेज़ अपलोड करें</h3>

                    {!preview ? (
                        <div className="space-y-4">
                            <input
                                ref={fileInputRef}
                                type="file"
                                accept="image/*"
                                onChange={handleFileSelect}
                                className="hidden"
                                id="file-upload"
                            />

                            <label
                                htmlFor="file-upload"
                                className="block border-2 border-dashed border-neutral-300 rounded-xl p-12 text-center cursor-pointer hover:border-primary-500 hover:bg-primary-50/50 transition-all"
                            >
                                <Upload className="w-12 h-12 mx-auto mb-4 text-neutral-400" />
                                <p className="text-neutral-700 font-medium mb-2">फ़ाइल चुनने के लिए क्लिक करें</p>
                                <p className="text-sm text-neutral-500">या यहां फ़ाइल खींचें और छोड़ें</p>
                                <p className="text-xs text-neutral-400 mt-2">JPG, PNG, PDF (अधिकतम 10MB)</p>
                            </label>

                            <div className="relative">
                                <div className="absolute inset-0 flex items-center">
                                    <div className="w-full border-t border-neutral-200" />
                                </div>
                                <div className="relative flex justify-center text-sm">
                                    <span className="px-2 bg-white text-neutral-500">या</span>
                                </div>
                            </div>

                            <Button
                                variant="outline"
                                className="w-full"
                                icon={<Camera className="w-5 h-5" />}
                                onClick={() => alert('कैमरा फीचर जल्द आ रहा है')}
                            >
                                कैमरे से फोटो लें
                            </Button>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {/* Preview */}
                            <div className="relative">
                                <img
                                    src={preview}
                                    alt="Document preview"
                                    className="w-full h-64 object-contain bg-neutral-100 rounded-lg"
                                />
                                <button
                                    onClick={handleReset}
                                    className="absolute top-2 right-2 w-8 h-8 bg-error text-white rounded-full flex items-center justify-center hover:bg-error/90 transition-colors"
                                >
                                    <X className="w-5 h-5" />
                                </button>
                            </div>

                            {/* File Info */}
                            <div className="flex items-center gap-3 p-3 bg-neutral-50 rounded-lg">
                                <FileText className="w-5 h-5 text-primary-500" />
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-neutral-900 truncate">
                                        {selectedFile?.name}
                                    </p>
                                    <p className="text-xs text-neutral-500">
                                        {(selectedFile?.size / 1024).toFixed(2)} KB
                                    </p>
                                </div>
                                {isComplete && (
                                    <Check className="w-5 h-5 text-success" />
                                )}
                            </div>

                            {/* Actions */}
                            <div className="flex gap-3">
                                <Button
                                    variant="primary"
                                    className="flex-1"
                                    onClick={handleScan}
                                    disabled={isProcessing || isComplete}
                                    loading={isProcessing}
                                >
                                    {isComplete ? 'स्कैन पूर्ण' : 'स्कैन करें'}
                                </Button>
                                <Button
                                    variant="outline"
                                    onClick={handleReset}
                                >
                                    रीसेट करें
                                </Button>
                            </div>
                        </div>
                    )}
                </Card>

                {/* Results Section */}
                <Card>
                    <h3 className="font-semibold text-lg mb-4">निकाला गया टेक्स्ट</h3>

                    {!extractedText ? (
                        <div className="flex flex-col items-center justify-center h-64 text-neutral-400">
                            <FileText className="w-16 h-16 mb-4 opacity-50" />
                            <p className="text-center">स्कैन किए गए टेक्स्ट यहां दिखाई देंगे</p>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            <div className="bg-neutral-50 rounded-lg p-4 max-h-96 overflow-y-auto">
                                <pre className="text-sm text-neutral-900 whitespace-pre-wrap font-hindi">
                                    {extractedText}
                                </pre>
                            </div>

                            <div className="flex gap-3">
                                <Button
                                    variant="primary"
                                    className="flex-1"
                                    onClick={() => {
                                        navigator.clipboard.writeText(extractedText);
                                        alert('टेक्स्ट कॉपी किया गया!');
                                    }}
                                >
                                    टेक्स्ट कॉपी करें
                                </Button>
                                <Button
                                    variant="outline"
                                    onClick={() => {
                                        const blob = new Blob([extractedText], { type: 'text/plain' });
                                        const url = URL.createObjectURL(blob);
                                        const a = document.createElement('a');
                                        a.href = url;
                                        a.download = `document_${Date.now()}.txt`;
                                        a.click();
                                    }}
                                >
                                    डाउनलोड करें
                                </Button>
                            </div>
                        </div>
                    )}
                </Card>
            </div>

            {/* Recent Scans */}
            <Card>
                <h3 className="font-semibold text-lg mb-4">हाल के स्कैन</h3>
                <div className="text-center py-8 text-neutral-400">
                    <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>अभी तक कोई स्कैन नहीं</p>
                </div>
            </Card>
        </div>
    );
}
