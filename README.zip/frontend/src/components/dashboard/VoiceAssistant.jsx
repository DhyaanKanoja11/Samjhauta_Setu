import { useState } from 'react';
import { Volume2, X, MessageCircle } from 'lucide-react';
import VoiceButton from '../common/VoiceButton';
import Card from '../common/Card';

export default function VoiceAssistant() {
    const [isOpen, setIsOpen] = useState(false);
    const [transcript, setTranscript] = useState('');
    const [response, setResponse] = useState('');
    const [conversation, setConversation] = useState([]);
    const [isProcessing, setIsProcessing] = useState(false);

    const handleTranscript = (text) => {
        setTranscript(text);
        setIsProcessing(true);

        // Add user message to conversation
        const userMessage = { type: 'user', text, timestamp: new Date() };
        setConversation(prev => [...prev, userMessage]);

        // Simulate AI response (will be replaced with actual API call)
        setTimeout(() => {
            const mockResponse = generateMockResponse(text);
            const aiMessage = { type: 'ai', text: mockResponse, timestamp: new Date() };
            setConversation(prev => [...prev, aiMessage]);
            setResponse(mockResponse);
            setIsProcessing(false);

            // Speak the response (if browser supports it)
            speakText(mockResponse);
        }, 1500);
    };

    const generateMockResponse = (query) => {
        const lowerQuery = query.toLowerCase();

        if (lowerQuery.includes('गेहूं') || lowerQuery.includes('wheat')) {
            return 'आज गेहूं का भाव ₹2,150 प्रति क्विंटल है। पिछले हफ्ते से ₹50 की बढ़ोतरी हुई है।';
        } else if (lowerQuery.includes('धान') || lowerQuery.includes('rice')) {
            return 'धान का आज का भाव ₹1,950 प्रति क्विंटल है। कीमत में ₹30 की कमी आई है।';
        } else if (lowerQuery.includes('मौसम') || lowerQuery.includes('weather')) {
            return 'आज का मौसम साफ रहने की संभावना है। तापमान 25-30 डिग्री रहेगा।';
        } else if (lowerQuery.includes('योजना') || lowerQuery.includes('scheme')) {
            return 'किसान सम्मान निधि योजना के तहत अगली किस्त अगले महीने आएगी।';
        }

        return 'मैं आपकी मदद के लिए यहां हूं। कृपया मंडी भाव, मौसम, या सरकारी योजनाओं के बारे में पूछें।';
    };

    const speakText = (text) => {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'hi-IN';
            utterance.rate = 0.9;
            window.speechSynthesis.speak(utterance);
        }
    };

    const handleError = (error) => {
        console.error('Voice error:', error);
        setConversation(prev => [...prev, {
            type: 'error',
            text: 'क्षमा करें, आवाज़ सुनने में समस्या हुई। कृपया फिर से कोशिश करें।',
            timestamp: new Date()
        }]);
    };

    return (
        <>
            {/* Floating Voice Button */}
            <div className="fixed bottom-6 right-6 z-50">
                <VoiceButton
                    onTranscript={handleTranscript}
                    onError={handleError}
                    className="shadow-strong"
                />
            </div>

            {/* Voice Assistant Panel */}
            {isOpen && (
                <div className="fixed bottom-28 right-6 w-96 max-w-[calc(100vw-3rem)] z-50 animate-slide-up">
                    <Card variant="glass" className="!p-0 overflow-hidden">
                        {/* Header */}
                        <div className="bg-gradient-primary p-4 text-white flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <MessageCircle className="w-5 h-5" />
                                <h3 className="font-semibold">आवाज़ सहायक</h3>
                            </div>
                            <button
                                onClick={() => setIsOpen(false)}
                                className="touch-target w-8 h-8 hover:bg-white/20 rounded-lg transition-colors"
                            >
                                <X className="w-5 h-5" />
                            </button>
                        </div>

                        {/* Conversation */}
                        <div className="p-4 max-h-96 overflow-y-auto space-y-3">
                            {conversation.length === 0 ? (
                                <div className="text-center py-8 text-neutral-500">
                                    <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                                    <p>माइक बटन दबाएं और बोलना शुरू करें</p>
                                    <p className="text-sm mt-2">मंडी भाव, मौसम, योजनाओं के बारे में पूछें</p>
                                </div>
                            ) : (
                                conversation.map((msg, idx) => (
                                    <div
                                        key={idx}
                                        className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
                                    >
                                        <div
                                            className={`max-w-[80%] p-3 rounded-lg ${msg.type === 'user'
                                                    ? 'bg-primary-500 text-white'
                                                    : msg.type === 'error'
                                                        ? 'bg-error/10 text-error'
                                                        : 'bg-neutral-100 text-neutral-900'
                                                }`}
                                        >
                                            <p className="text-sm">{msg.text}</p>
                                            <p className="text-xs opacity-70 mt-1">
                                                {msg.timestamp.toLocaleTimeString('hi-IN', {
                                                    hour: '2-digit',
                                                    minute: '2-digit'
                                                })}
                                            </p>
                                        </div>
                                    </div>
                                ))
                            )}

                            {isProcessing && (
                                <div className="flex justify-start">
                                    <div className="bg-neutral-100 p-3 rounded-lg">
                                        <div className="flex gap-1">
                                            <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" />
                                            <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce delay-100" />
                                            <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce delay-200" />
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Quick Actions */}
                        <div className="p-4 bg-neutral-50 border-t border-neutral-200">
                            <p className="text-xs text-neutral-600 mb-2">त्वरित प्रश्न:</p>
                            <div className="flex flex-wrap gap-2">
                                {['गेहूं का भाव?', 'आज का मौसम?', 'नई योजनाएं?'].map((q, idx) => (
                                    <button
                                        key={idx}
                                        onClick={() => handleTranscript(q)}
                                        className="px-3 py-1 text-xs bg-white border border-neutral-200 rounded-full hover:bg-neutral-100 transition-colors"
                                    >
                                        {q}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </Card>
                </div>
            )}

            {/* Toggle Button (when panel is closed) */}
            {!isOpen && conversation.length > 0 && (
                <button
                    onClick={() => setIsOpen(true)}
                    className="fixed bottom-28 right-6 bg-white shadow-medium rounded-full px-4 py-2 flex items-center gap-2 hover:shadow-strong transition-all z-40 animate-slide-up"
                >
                    <MessageCircle className="w-4 h-4 text-primary-500" />
                    <span className="text-sm font-medium">{conversation.length} संदेश</span>
                </button>
            )}
        </>
    );
}
