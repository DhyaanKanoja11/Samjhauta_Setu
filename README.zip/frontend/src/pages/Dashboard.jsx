import { TrendingUp, FileText, Scale, AlertCircle, Calendar } from 'lucide-react';
import MandiPrices from '../components/dashboard/MandiPrices';
import VoiceAssistant from '../components/dashboard/VoiceAssistant';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { Link } from 'react-router-dom';

export default function Dashboard() {
    // Mock data for stats
    const stats = [
        {
            label: 'सक्रिय विवाद',
            value: '3',
            change: '+1',
            icon: Scale,
            color: 'text-accent-500',
            bgColor: 'bg-accent-50',
        },
        {
            label: 'हल किए गए',
            value: '12',
            change: '+3',
            icon: FileText,
            color: 'text-success',
            bgColor: 'bg-success/10',
        },
        {
            label: 'औसत मंडी भाव',
            value: '₹2,850',
            change: '+2.5%',
            icon: TrendingUp,
            color: 'text-primary-500',
            bgColor: 'bg-primary-50',
        },
    ];

    const recentCases = [
        {
            id: 1,
            title: 'भूमि विवाद - खसरा 456',
            status: 'चल रहा है',
            date: '2 दिन पहले',
            priority: 'उच्च',
        },
        {
            id: 2,
            title: 'फसल बीमा दावा',
            status: 'समीक्षा में',
            date: '5 दिन पहले',
            priority: 'मध्यम',
        },
        {
            id: 3,
            title: 'पानी के अधिकार',
            status: 'नया',
            date: '1 सप्ताह पहले',
            priority: 'निम्न',
        },
    ];

    const getPriorityColor = (priority) => {
        switch (priority) {
            case 'उच्च': return 'badge-error';
            case 'मध्यम': return 'badge-warning';
            case 'निम्न': return 'badge-info';
            default: return 'badge-info';
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'चल रहा है': return 'badge-warning';
            case 'समीक्षा में': return 'badge-info';
            case 'नया': return 'badge-success';
            default: return 'badge-info';
        }
    };

    return (
        <div className="min-h-screen bg-neutral-50 pb-24 md:pb-8">
            <div className="container-custom py-6 md:py-8 space-y-8">
                {/* Welcome Section */}
                <div className="animate-fade-in">
                    <h1 className="text-3xl md:text-4xl font-bold text-neutral-900">
                        नमस्ते, किसान भाई 🙏
                    </h1>
                    <p className="text-neutral-600 mt-2">
                        आज का दिन: {new Date().toLocaleDateString('hi-IN', {
                            weekday: 'long',
                            day: 'numeric',
                            month: 'long',
                            year: 'numeric'
                        })}
                    </p>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 animate-slide-up">
                    {stats.map((stat, idx) => {
                        const Icon = stat.icon;
                        return (
                            <Card key={idx} variant="hover">
                                <div className="flex items-start justify-between">
                                    <div>
                                        <p className="text-sm text-neutral-600 mb-1">{stat.label}</p>
                                        <p className="text-3xl font-bold text-neutral-900">{stat.value}</p>
                                        <p className={`text-sm font-medium mt-2 ${stat.change.startsWith('+') ? 'text-success' : 'text-error'}`}>
                                            {stat.change} इस महीने
                                        </p>
                                    </div>
                                    <div className={`${stat.bgColor} ${stat.color} w-12 h-12 rounded-lg flex items-center justify-center`}>
                                        <Icon className="w-6 h-6" />
                                    </div>
                                </div>
                            </Card>
                        );
                    })}
                </div>

                {/* Quick Actions */}
                <Card className="animate-slide-up delay-100">
                    <h2 className="text-xl font-semibold mb-4">त्वरित कार्य</h2>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <Link to="/cases/new">
                            <button className="w-full p-4 rounded-lg border-2 border-neutral-200 hover:border-primary-500 hover:bg-primary-50 transition-all text-center group">
                                <Scale className="w-8 h-8 mx-auto mb-2 text-neutral-400 group-hover:text-primary-500 transition-colors" />
                                <p className="text-sm font-medium text-neutral-700 group-hover:text-primary-600">नया विवाद</p>
                            </button>
                        </Link>
                        <Link to="/documents">
                            <button className="w-full p-4 rounded-lg border-2 border-neutral-200 hover:border-primary-500 hover:bg-primary-50 transition-all text-center group">
                                <FileText className="w-8 h-8 mx-auto mb-2 text-neutral-400 group-hover:text-primary-500 transition-colors" />
                                <p className="text-sm font-medium text-neutral-700 group-hover:text-primary-600">स्कैन करें</p>
                            </button>
                        </Link>
                        <Link to="/mandi">
                            <button className="w-full p-4 rounded-lg border-2 border-neutral-200 hover:border-primary-500 hover:bg-primary-50 transition-all text-center group">
                                <TrendingUp className="w-8 h-8 mx-auto mb-2 text-neutral-400 group-hover:text-primary-500 transition-colors" />
                                <p className="text-sm font-medium text-neutral-700 group-hover:text-primary-600">मंडी भाव</p>
                            </button>
                        </Link>
                        <Link to="/profile">
                            <button className="w-full p-4 rounded-lg border-2 border-neutral-200 hover:border-primary-500 hover:bg-primary-50 transition-all text-center group">
                                <Calendar className="w-8 h-8 mx-auto mb-2 text-neutral-400 group-hover:text-primary-500 transition-colors" />
                                <p className="text-sm font-medium text-neutral-700 group-hover:text-primary-600">योजनाएं</p>
                            </button>
                        </Link>
                    </div>
                </Card>

                {/* Main Content Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
                    {/* Left Column - Mandi Prices */}
                    <div className="lg:col-span-2 animate-slide-up delay-200">
                        <MandiPrices compact />
                    </div>

                    {/* Right Column - Recent Cases */}
                    <div className="animate-slide-up delay-300">
                        <Card>
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="text-xl font-semibold">हाल के विवाद</h2>
                                <Link to="/cases" className="text-sm text-primary-500 hover:text-primary-600 font-medium">
                                    सभी देखें →
                                </Link>
                            </div>

                            {recentCases.length === 0 ? (
                                <div className="text-center py-12 text-neutral-400">
                                    <Scale className="w-12 h-12 mx-auto mb-3 opacity-50" />
                                    <p>कोई विवाद नहीं</p>
                                </div>
                            ) : (
                                <div className="space-y-3">
                                    {recentCases.map((caseItem) => (
                                        <Link
                                            key={caseItem.id}
                                            to={`/cases/${caseItem.id}`}
                                            className="block p-4 rounded-lg border border-neutral-200 hover:border-primary-500 hover:bg-primary-50/50 transition-all"
                                        >
                                            <div className="flex items-start justify-between mb-2">
                                                <h3 className="font-medium text-neutral-900 text-sm">
                                                    {caseItem.title}
                                                </h3>
                                                <span className={`badge ${getPriorityColor(caseItem.priority)} text-xs`}>
                                                    {caseItem.priority}
                                                </span>
                                            </div>
                                            <div className="flex items-center justify-between">
                                                <span className={`badge ${getStatusColor(caseItem.status)} text-xs`}>
                                                    {caseItem.status}
                                                </span>
                                                <span className="text-xs text-neutral-500">{caseItem.date}</span>
                                            </div>
                                        </Link>
                                    ))}
                                </div>
                            )}

                            <Link to="/cases/new" className="btn-outline w-full mt-4 text-center">
                                नया विवाद दर्ज करें
                            </Link>
                        </Card>

                        {/* Important Notice */}
                        <Card className="mt-6 bg-warning/5 border-warning/20">
                            <div className="flex gap-3">
                                <AlertCircle className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
                                <div>
                                    <h3 className="font-semibold text-neutral-900 mb-1">महत्वपूर्ण सूचना</h3>
                                    <p className="text-sm text-neutral-700">
                                        किसान सम्मान निधि की अगली किस्त 15 फरवरी को जारी होगी।
                                        कृपया अपने बैंक खाते की जानकारी अपडेट करें।
                                    </p>
                                </div>
                            </div>
                        </Card>
                    </div>
                </div>
            </div>

            {/* Voice Assistant (Floating) */}
            <VoiceAssistant />
        </div>
    );
}
