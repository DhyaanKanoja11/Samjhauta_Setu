import Card from '../components/common/Card';
import { Scale, Clock, CheckCircle } from 'lucide-react';
import VoiceAssistant from '../components/dashboard/VoiceAssistant';

export default function CasesPage() {
    const cases = [
        {
            id: 1,
            title: 'भूमि विवाद - खसरा 456',
            description: 'पड़ोसी के साथ सीमा विवाद',
            status: 'चल रहा है',
            priority: 'उच्च',
            date: '2024-02-10',
            parties: ['राजेश कुमार', 'सुरेश शर्मा'],
        },
        {
            id: 2,
            title: 'फसल बीमा दावा',
            description: 'ओलावृष्टि से फसल क्षति',
            status: 'समीक्षा में',
            priority: 'मध्यम',
            date: '2024-02-07',
            parties: ['राजेश कुमार', 'बीमा कंपनी'],
        },
        {
            id: 3,
            title: 'पानी के अधिकार',
            description: 'सिंचाई नहर का उपयोग',
            status: 'हल हो गया',
            priority: 'निम्न',
            date: '2024-02-01',
            parties: ['राजेश कुमार', 'ग्राम पंचायत'],
        },
    ];

    const getStatusIcon = (status) => {
        switch (status) {
            case 'चल रहा है': return <Clock className="w-5 h-5" />;
            case 'समीक्षा में': return <Clock className="w-5 h-5" />;
            case 'हल हो गया': return <CheckCircle className="w-5 h-5" />;
            default: return <Scale className="w-5 h-5" />;
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'चल रहा है': return 'badge-warning';
            case 'समीक्षा में': return 'badge-info';
            case 'हल हो गया': return 'badge-success';
            default: return 'badge-info';
        }
    };

    const getPriorityColor = (priority) => {
        switch (priority) {
            case 'उच्च': return 'badge-error';
            case 'मध्यम': return 'badge-warning';
            case 'निम्न': return 'badge-info';
            default: return 'badge-info';
        }
    };

    return (
        <div className="min-h-screen bg-neutral-50 pb-24 md:pb-8">
            <div className="container-custom py-6 md:py-8 space-y-6">
                <div className="flex items-center justify-between flex-wrap gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-neutral-900">मेरे विवाद</h1>
                        <p className="text-neutral-600 mt-1">सभी विवादों का प्रबंधन करें</p>
                    </div>
                    <button className="btn-primary">
                        नया विवाद दर्ज करें
                    </button>
                </div>

                {/* Filters */}
                <Card className="!p-4">
                    <div className="flex gap-3 flex-wrap">
                        <button className="px-4 py-2 rounded-lg bg-primary-500 text-white text-sm font-medium">
                            सभी ({cases.length})
                        </button>
                        <button className="px-4 py-2 rounded-lg bg-neutral-100 text-neutral-700 text-sm font-medium hover:bg-neutral-200">
                            चल रहे ({cases.filter(c => c.status === 'चल रहा है').length})
                        </button>
                        <button className="px-4 py-2 rounded-lg bg-neutral-100 text-neutral-700 text-sm font-medium hover:bg-neutral-200">
                            समीक्षा में ({cases.filter(c => c.status === 'समीक्षा में').length})
                        </button>
                        <button className="px-4 py-2 rounded-lg bg-neutral-100 text-neutral-700 text-sm font-medium hover:bg-neutral-200">
                            हल हो गए ({cases.filter(c => c.status === 'हल हो गया').length})
                        </button>
                    </div>
                </Card>

                {/* Cases List */}
                <div className="space-y-4">
                    {cases.map((caseItem) => (
                        <Card key={caseItem.id} variant="hover">
                            <div className="flex items-start gap-4">
                                <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${caseItem.status === 'हल हो गया' ? 'bg-success/10 text-success' :
                                        caseItem.status === 'चल रहा है' ? 'bg-warning/10 text-warning' :
                                            'bg-info/10 text-info'
                                    }`}>
                                    {getStatusIcon(caseItem.status)}
                                </div>

                                <div className="flex-1 min-w-0">
                                    <div className="flex items-start justify-between gap-4 mb-2">
                                        <div>
                                            <h3 className="font-semibold text-lg text-neutral-900">
                                                {caseItem.title}
                                            </h3>
                                            <p className="text-sm text-neutral-600 mt-1">
                                                {caseItem.description}
                                            </p>
                                        </div>
                                        <span className={`badge ${getPriorityColor(caseItem.priority)} flex-shrink-0`}>
                                            {caseItem.priority}
                                        </span>
                                    </div>

                                    <div className="flex items-center gap-4 flex-wrap mt-3">
                                        <span className={`badge ${getStatusColor(caseItem.status)}`}>
                                            {caseItem.status}
                                        </span>
                                        <span className="text-sm text-neutral-500">
                                            दर्ज: {new Date(caseItem.date).toLocaleDateString('hi-IN')}
                                        </span>
                                        <span className="text-sm text-neutral-500">
                                            पक्षकार: {caseItem.parties.join(', ')}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </Card>
                    ))}
                </div>
            </div>
            <VoiceAssistant />
        </div>
    );
}
