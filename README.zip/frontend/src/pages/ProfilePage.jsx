import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { User, MapPin, Phone, Mail, Edit, Camera } from 'lucide-react';
import VoiceAssistant from '../components/dashboard/VoiceAssistant';

export default function ProfilePage() {
    const userInfo = {
        name: 'राजेश कुमार',
        fatherName: 'रामप्रसाद शर्मा',
        village: 'रामपुर',
        district: 'मेरठ',
        state: 'उत्तर प्रदेश',
        phone: '+91 98765 43210',
        email: 'rajesh.kumar@example.com',
        landHolding: '2.5 एकड़',
        crops: ['गेहूं', 'धान', 'गन्ना'],
    };

    return (
        <div className="min-h-screen bg-neutral-50 pb-24 md:pb-8">
            <div className="container-custom py-6 md:py-8 space-y-6">
                <div>
                    <h1 className="text-3xl font-bold text-neutral-900">मेरी प्रोफ़ाइल</h1>
                    <p className="text-neutral-600 mt-1">अपनी जानकारी देखें और अपडेट करें</p>
                </div>

                {/* Profile Header */}
                <Card>
                    <div className="flex flex-col md:flex-row items-center gap-6">
                        <div className="relative">
                            <div className="w-24 h-24 rounded-full bg-gradient-primary flex items-center justify-center text-white text-3xl font-bold">
                                {userInfo.name.charAt(0)}
                            </div>
                            <button className="absolute bottom-0 right-0 w-8 h-8 bg-primary-500 text-white rounded-full flex items-center justify-center hover:bg-primary-600 transition-colors">
                                <Camera className="w-4 h-4" />
                            </button>
                        </div>

                        <div className="flex-1 text-center md:text-left">
                            <h2 className="text-2xl font-bold text-neutral-900">{userInfo.name}</h2>
                            <p className="text-neutral-600">पिता: {userInfo.fatherName}</p>
                            <div className="flex items-center gap-2 mt-2 justify-center md:justify-start">
                                <MapPin className="w-4 h-4 text-neutral-500" />
                                <span className="text-sm text-neutral-600">
                                    {userInfo.village}, {userInfo.district}, {userInfo.state}
                                </span>
                            </div>
                        </div>

                        <Button variant="outline" icon={<Edit className="w-4 h-4" />}>
                            संपादित करें
                        </Button>
                    </div>
                </Card>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Personal Information */}
                    <Card>
                        <h3 className="text-xl font-semibold mb-4">व्यक्तिगत जानकारी</h3>
                        <div className="space-y-4">
                            <div className="flex items-center gap-3 p-3 bg-neutral-50 rounded-lg">
                                <Phone className="w-5 h-5 text-primary-500" />
                                <div>
                                    <p className="text-xs text-neutral-500">मोबाइल नंबर</p>
                                    <p className="font-medium text-neutral-900">{userInfo.phone}</p>
                                </div>
                            </div>

                            <div className="flex items-center gap-3 p-3 bg-neutral-50 rounded-lg">
                                <Mail className="w-5 h-5 text-primary-500" />
                                <div>
                                    <p className="text-xs text-neutral-500">ईमेल</p>
                                    <p className="font-medium text-neutral-900">{userInfo.email}</p>
                                </div>
                            </div>

                            <div className="flex items-center gap-3 p-3 bg-neutral-50 rounded-lg">
                                <MapPin className="w-5 h-5 text-primary-500" />
                                <div>
                                    <p className="text-xs text-neutral-500">पता</p>
                                    <p className="font-medium text-neutral-900">
                                        {userInfo.village}, {userInfo.district}, {userInfo.state}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </Card>

                    {/* Farming Information */}
                    <Card>
                        <h3 className="text-xl font-semibold mb-4">खेती की जानकारी</h3>
                        <div className="space-y-4">
                            <div className="p-3 bg-neutral-50 rounded-lg">
                                <p className="text-xs text-neutral-500 mb-1">कुल भूमि</p>
                                <p className="text-2xl font-bold text-primary-600">{userInfo.landHolding}</p>
                            </div>

                            <div className="p-3 bg-neutral-50 rounded-lg">
                                <p className="text-xs text-neutral-500 mb-2">मुख्य फसलें</p>
                                <div className="flex flex-wrap gap-2">
                                    {userInfo.crops.map((crop, idx) => (
                                        <span key={idx} className="badge badge-success">
                                            {crop}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </Card>
                </div>

                {/* Statistics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card className="text-center">
                        <p className="text-3xl font-bold text-primary-600">15</p>
                        <p className="text-neutral-600 mt-1">कुल विवाद</p>
                    </Card>
                    <Card className="text-center">
                        <p className="text-3xl font-bold text-success">12</p>
                        <p className="text-neutral-600 mt-1">हल किए गए</p>
                    </Card>
                    <Card className="text-center">
                        <p className="text-3xl font-bold text-warning">3</p>
                        <p className="text-neutral-600 mt-1">लंबित</p>
                    </Card>
                </div>

                {/* Government Schemes */}
                <Card>
                    <h3 className="text-xl font-semibold mb-4">सरकारी योजनाएं</h3>
                    <div className="space-y-3">
                        <div className="p-4 border border-neutral-200 rounded-lg hover:border-primary-500 transition-colors">
                            <div className="flex items-start justify-between">
                                <div>
                                    <h4 className="font-semibold text-neutral-900">किसान सम्मान निधि</h4>
                                    <p className="text-sm text-neutral-600 mt-1">₹6,000 प्रति वर्ष</p>
                                </div>
                                <span className="badge badge-success">सक्रिय</span>
                            </div>
                        </div>

                        <div className="p-4 border border-neutral-200 rounded-lg hover:border-primary-500 transition-colors">
                            <div className="flex items-start justify-between">
                                <div>
                                    <h4 className="font-semibold text-neutral-900">फसल बीमा योजना</h4>
                                    <p className="text-sm text-neutral-600 mt-1">प्राकृतिक आपदा कवरेज</p>
                                </div>
                                <span className="badge badge-success">सक्रिय</span>
                            </div>
                        </div>

                        <div className="p-4 border border-neutral-200 rounded-lg hover:border-primary-500 transition-colors">
                            <div className="flex items-start justify-between">
                                <div>
                                    <h4 className="font-semibold text-neutral-900">मृदा स्वास्थ्य कार्ड</h4>
                                    <p className="text-sm text-neutral-600 mt-1">मिट्टी परीक्षण रिपोर्ट</p>
                                </div>
                                <span className="badge badge-info">लागू करें</span>
                            </div>
                        </div>
                    </div>
                </Card>
            </div>
            <VoiceAssistant />
        </div>
    );
}
